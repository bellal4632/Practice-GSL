<?php

if (isset($_POST['sub']))

{
    $name=$_POST['name'];
    $roll=$_POST['roll'];
    $sem1=$_POST['semone'];
    $sem2=$_POST['semtwo'];
    $sem3=$_POST['semthree'];
    $sem4=$_POST['semfour'];
    $sem5=$_POST['semfive'];
    $sem6=$_POST['semsix'];
    $sem7=$_POST['semseven'];
    $sem8=$_POST['semeight'];
    
    $total=($sem1*0.05)+($sem2*0.05)+($sem3*0.05)+($sem4*0.10)+($sem5*0.15)+($sem6*0.20)+($sem7*0.25)+($sem8*0.15);  

    if ($total>=3.76 && $total<=4.00) {
        $grade="<h3><center>Congratulations, You Got A+</center></h3>";
    }
    elseif ($total>=3.51 && $total<=3.75) {
        $grade="<h3><center>Congratulations, You Got A</center></h3>";
    }
    elseif ($total>=3.26 && $total<=3.50) {
        $grade="<h3><center>Congratulations, You Got A-</center></h3>";
    }
    elseif ($total>=3.49 && $total<=3.25) {
        $grade="<h3><center>Congratulations, You Got B+</center></h3>";
    }
    elseif ($total>=3.24 && $total<=3.00) {
        $grade="<h3><center>Congratulations, You Got B</center></h3>";
    }
    elseif ($total>=2.99 && $total<=2.75) {
        $grade="<h3><center>Congratulations, You Got B-</center></h3>";
    }
    elseif ($total>=2.74 && $total<=2.50) {
        $grade="<h3><center>Congratulations, You Got C+</center></h3>";
    }
    elseif ($total>=2.49 && $total<=2.25) {
        $grade="<h3><center>Congratulations, You Got C</center></h3>";
    }
    elseif ($total>=2.24 && $total<=2.00) {
        $grade="<h3><center>Congratulations, You Got D</center></h3>";
    }
    elseif ($total<=1.99) {
        $grade="<h3><center>Sorry You're Failed, Better Luck For Next Time</center></h3>";
    }
    else {
        $grade="<h3><center>You Have Enter Wrong GPA. Please Check And Input Valid GPA. </br> Thank You</center></h3>";
    }

    echo "<h2><center>$grade </center></h2>";
    
    echo "<h2>Name : $name </h2>";
    echo "<h2>Roll No : $roll </h2>";
    
    echo "<p> <b> 1st Semester GPA : </b> $sem1 </center></p>";
    echo "<p> <b> 2nd Semester GPA : </b> $sem2 </center></p>";
    echo "<p> <b> 3rd Semester GPA : </b> $sem3 </center></p>";
    echo "<p> <b> 4th Semester GPA : </b> $sem4 </center></p>";
    echo "<p> <b> 5th Semester GPA : </b> $sem5 </center></p>";
    echo "<p> <b> 6th Semester GPA : </b> $sem6 </center></p>";
    echo "<p> <b> 7th Semester GPA : </b> $sem7 </center></p>";
    echo "<p> <b> 8th Semester GPA : </b> $sem8 </center></p>";

    echo "<h4> Your Total Grade Point Is : $total</h4>";

}
?>