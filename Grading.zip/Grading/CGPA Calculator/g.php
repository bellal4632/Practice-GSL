<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GRADING SYSTEM BY PHP</title>
    <link rel="stylesheet" href="BS/css/bootstrap.min.css">
    <script src="BS/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <br>
    <div class="container bg-success py-2">
    
    <h2 class="text-center bg-dark text-light p-1"><hr>Student Grading System<hr></h2>

        <form action="code.php" method="post">
            
            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>Enter Your Name</b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="name" placeholder="Your Full Name">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>Enter Your Roll</b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="roll" placeholder="Your Roll Number">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>1st Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semone" placeholder="Your First Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>2nd Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semtwo" placeholder="Your second Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>3rd Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semthree" placeholder="Your Third Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>4th Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semfour" placeholder="Your Forth Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>5th Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semfive" placeholder="Your Fifth Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>6th Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semsix" placeholder="Your Sixth Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>7th Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semseven" placeholder="Your Seventh Semester GPA">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="fname" class="col-sm-3 col-form-label"><b>8th Semester GPA </b></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="semeight" placeholder="Your Eighth Semester GPA">
                </div>
            </div>

            <div class="col-12 d-flex justify-content-center">
                <input class="btn btn-primary" type="submit" value="Get Your CGPA" name="sub">
            </div>
            
        </form>
    </div>
    
</body>
</html>